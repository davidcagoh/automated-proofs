# Summary of changes
I formalized and proved that √2 is irrational in `RequestProject/Sqrt2Irrational.lean`.

The theorem is stated as:
```lean
theorem sqrt2_irrational : Irrational (Real.sqrt 2)
```

The proof uses Mathlib's existing `irrational_sqrt_two` lemma, which establishes this classic result. The file compiles successfully with no sorries.