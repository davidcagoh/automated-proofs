import Mathlib

theorem sqrt2_irrational : Irrational (Real.sqrt 2) := by
  -- The irrationality of √2 is a well-known result, so we can use the existing theorem.
  apply irrational_sqrt_two